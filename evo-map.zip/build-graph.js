// Builds EVO's own road graph for one area from OpenStreetMap roads (osmium geojsonseq) -> compact binary used by the app's router.
// usage: node build-graph.js roads.geojsonseq out.bin
const fs = require('fs'); const readline = require('readline');
const SPEED = { motorway: 90, trunk: 75, primary: 60, secondary: 50, tertiary: 42, unclassified: 35, residential: 28, living_street: 15, service: 20, road: 30, track: 20 };
const base = (h) => String(h || '').replace(/_link$/, '');
const speedOf = (p) => { let v = (SPEED[base(p.highway)] || 25) * (/_link$/.test(p.highway) ? 0.7 : 1); const m = parseInt(p.maxspeed, 10); if (m > 0 && m <= 130) v = Math.min(m * 0.85, v * 1.2); return v; };
const dirOf = (p) => { const o = String(p.oneway || ''); if (o === '-1' || o === 'reverse') return -1; if (['yes', '1', 'true'].includes(o) || p.junction === 'roundabout' || /^motorway/.test(p.highway)) return 1; return 0; };
const hav = (a, b, c, d) => { const r = Math.PI / 180, x = Math.sin((c - a) * r / 2) ** 2 + Math.cos(a * r) * Math.cos(c * r) * Math.sin((d - b) * r / 2) ** 2; return 12742000 * Math.asin(Math.sqrt(x)); };
const ways = [];
const rl = readline.createInterface({ input: fs.createReadStream(process.argv[2]) });
rl.on('line', (l) => {
  l = l.replace(/^\x1e/, '').trim(); if (!l) return; let f; try { f = JSON.parse(l); } catch { return; }
  const g = f.geometry, p = f.properties || {}; if (!g || g.type !== 'LineString' || !SPEED[base(p.highway)]) return;
  if (['no', 'private'].includes(p.access) || p.motor_vehicle === 'no') return;
  ways.push({ c: g.coordinates, v: speedOf(p), d: dirOf(p) });
});
rl.on('close', () => {
  const ids = new Map(); const lat = []; const lon = [];
  const nid = (lo, la) => { const k = Math.round((lo + 180) * 1e5) * 2e7 + Math.round((la + 90) * 1e5); let i = ids.get(k); if (i === undefined) { i = lat.length; ids.set(k, i); lat.push(la); lon.push(lo); } return i; };
  const ef = [], et = [], etm = [], eds = [];
  for (const w of ways) for (let i = 0; i + 1 < w.c.length; i++) {
    const a = nid(w.c[i][0], w.c[i][1]), b = nid(w.c[i + 1][0], w.c[i + 1][1]); if (a === b) continue;
    const len = hav(w.c[i][1], w.c[i][0], w.c[i + 1][1], w.c[i + 1][0]), t = len / (w.v / 3.6);
    if (w.d !== -1) { ef.push(a); et.push(b); etm.push(t); eds.push(len); }
    if (w.d !== 1) { ef.push(b); et.push(a); etm.push(t); eds.push(len); }
  }
  // keep only the biggest connected piece, so a route never starts on an isolated road
  const N = lat.length, par = new Int32Array(N).map((_, i) => i);
  const find = (x) => { while (par[x] !== x) { par[x] = par[par[x]]; x = par[x]; } return x; };
  for (let i = 0; i < ef.length; i++) { const a = find(ef[i]), b = find(et[i]); if (a !== b) par[a] = b; }
  const sz = new Int32Array(N); for (let i = 0; i < N; i++) sz[find(i)]++;
  let big = 0; for (let i = 0; i < N; i++) if (sz[i] > sz[big]) big = i;
  const map = new Int32Array(N).fill(-1); let n = 0; const nl = [], no = [];
  for (let i = 0; i < N; i++) if (find(i) === find(big)) { map[i] = n++; nl.push(lat[i]); no.push(lon[i]); }
  const edges = []; for (let i = 0; i < ef.length; i++) if (map[ef[i]] >= 0 && map[et[i]] >= 0) edges.push(i);
  const m = edges.length, off = new Uint32Array(n + 1);
  for (const i of edges) off[map[ef[i]] + 1]++; for (let i = 0; i < n; i++) off[i + 1] += off[i];
  const pos = off.slice(0, n), to = new Uint32Array(m), tm = new Float32Array(m), ds = new Float32Array(m);
  for (const i of edges) { const p = pos[map[ef[i]]]++; to[p] = map[et[i]]; tm[p] = etm[i]; ds[p] = eds[i]; }
  const head = Buffer.alloc(12); head.write('EVG1', 0, 'ascii'); head.writeUInt32LE(n, 4); head.writeUInt32LE(m, 8);
  const buf = (ta) => Buffer.from(ta.buffer, ta.byteOffset, ta.byteLength);
  fs.writeFileSync(process.argv[3], Buffer.concat([head, buf(Float32Array.from(nl)), buf(Float32Array.from(no)), buf(off), buf(to), buf(tm), buf(ds)]));
  console.log(`graph: ${n} nodes, ${m} edges, ${(fs.statSync(process.argv[3]).size / 1e6).toFixed(1)} MB`);
});
