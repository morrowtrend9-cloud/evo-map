// Builds the map's font files (glyph PBFs) from the open Noto fonts: Latin + Arabic. Output: glyphs/<font name>/<start>-<end>.pbf
const fs = require('fs'); const path = require('path'); const fontnik = require('fontnik');
const find = (dir, name) => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name);
  if (e.isDirectory()) { const r = find(p, name); if (r) return r; } else if (e.name === name) return p; } return null; };
const FONTS = [['NotoSans_400Regular.ttf', 'Noto Sans Regular', '@expo-google-fonts/noto-sans'],
               ['NotoSansArabic_400Regular.ttf', 'Noto Sans Arabic Regular', '@expo-google-fonts/noto-sans-arabic']];
const range = (font, start, end) => new Promise((ok, no) => fontnik.range({ font, start, end }, (e, d) => (e ? no(e) : ok(d))));
(async () => {
  for (const [file, name, pkg] of FONTS) {
    const ttf = find(path.join('node_modules', pkg), file);
    if (!ttf) throw new Error(`font file not found: ${file} in ${pkg}`);
    const buf = fs.readFileSync(ttf); const out = path.join('glyphs', name); fs.mkdirSync(out, { recursive: true });
    for (let s = 0; s < 65536; s += 256) fs.writeFileSync(path.join(out, `${s}-${s + 255}.pbf`), await range(buf, s, s + 255));
    console.log('built', name);
  }
})().catch((e) => { console.error(e); process.exit(1); });
