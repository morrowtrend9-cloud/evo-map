# evo-map
Builds EVO's own map of one wilaya from OpenStreetMap data and publishes it to EVO's own Supabase Storage (bucket "map"):
- tiles/wNN.pmtiles : vector map with building heights (3D)
- graph/wNN.bin     : road graph used by the in-app router (best route, distance, ETA, order of stops)
- glyphs/           : Arabic + Latin map fonts
Map data (c) OpenStreetMap contributors, schema (c) OpenMapTiles.
